<h1><?php echo $producto->nombre; ?></h1>

<p><b>Precio:</b> $<?php echo $producto->precio; ?></p>

<p><b>Stock:</b> <?php echo $producto->stock; ?></p>

<p><b>Código:</b> <?php echo $producto->codigo; ?></p>

<p><?php echo $producto->descripcion; ?></p>

<a href="<?php echo base_url(); ?>index.php/productos">Volver</a>