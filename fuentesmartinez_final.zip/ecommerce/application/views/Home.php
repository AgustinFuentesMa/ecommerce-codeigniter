<?php if($this->session->userdata('logueado')){ ?>

<div style="background:#d4edda; padding:10px; margin-bottom:10px;">
    <b>Bienvenido <?php echo $this->session->userdata('nombre'); ?></b>
    <br>
    <a href="<?php echo base_url('index.php/productos/logout'); ?>">Cerrar sesión</a>
</div>

<?php } else { ?>

<div style="background:#f8d7da; padding:10px; margin-bottom:10px;">
    <a href="<?php echo base_url('index.php/productos/login'); ?>">Login</a> |
    <a href="<?php echo base_url('index.php/productos/registro'); ?>">Registro</a>
</div>

<?php } ?>

<hr>

<h1>Listado de Productos</h1>

<?php foreach($productos as $p){ ?>

<div style="border:1px solid gray; padding:10px; margin:10px; width:250px;">

<h3><?php echo $p->nombre; ?></h3>

<p>Precio: $<?php echo $p->precio; ?></p>

<a href="<?php echo base_url('index.php/productos/detalle/'.$p->id); ?>">
Ver detalle
</a>

</div>

<?php } ?>