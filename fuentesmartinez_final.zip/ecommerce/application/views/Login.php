<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5" style="max-width:400px;">

<h2 class="mb-4 text-center">Iniciar sesión</h2>

<?php if($this->session->flashdata('error')){ ?>
<div class="alert alert-danger">
<?php echo $this->session->flashdata('error'); ?>
</div>
<?php } ?>

<form method="post">

<input class="form-control mb-3" type="email" name="email" placeholder="Email" required>

<input class="form-control mb-3" type="password" name="password" placeholder="Contraseña" required>

<button class="btn btn-success w-100">Ingresar</button>

</form>

<p class="mt-3 text-center">
¿No tenés cuenta? 
<a href="<?php echo base_url('index.php/productos/registro'); ?>">Registrate</a>
</p>

</div>

</body>
</html>