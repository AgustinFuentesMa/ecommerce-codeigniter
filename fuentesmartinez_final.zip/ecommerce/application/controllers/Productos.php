<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productos extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
        $this->load->model('Producto_model');
        $this->load->model('Usuario_model');
    }

    public function index(){
        $data['productos'] = $this->Producto_model->get_productos();
        $this->load->view('home', $data);
    }

    public function detalle($id){
        $data['producto'] = $this->Producto_model->get_producto($id);
        $this->load->view('detalle', $data);
    }

    public function registro(){

        if($this->input->post()){

            $nombre = $this->input->post('nombre');
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            // verificar email
            if($this->Usuario_model->existe_email($email)){
                echo "Email ya registrado";
                return;
            }

            // guardar usuario
            $data = [
                'nombre' => $nombre,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT)
            ];

            $this->Usuario_model->registrar($data);

            // LOGUEAR AUTOMÁTICAMENTE
            $usuario = $this->Usuario_model->login($email);

            $this->session->set_userdata([
                'usuario_id' => $usuario->id,
                'nombre' => $usuario->nombre,
                'logueado' => true
            ]);

            redirect('productos');
        }

        $this->load->view('registro');
    }

    public function login(){

        if($this->input->post()){

            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $usuario = $this->Usuario_model->login($email);

            if($usuario && password_verify($password, $usuario->password)){

                $this->session->set_userdata([
                    'usuario_id' => $usuario->id,
                    'nombre' => $usuario->nombre,
                    'logueado' => true
                ]);

                redirect('productos');

            } else {
                echo "Email o contraseña incorrectos";
            }

            return;
        }

        $this->load->view('login');
    }

    public function logout(){
        $this->session->sess_destroy();
        redirect('productos/login');
    }
}