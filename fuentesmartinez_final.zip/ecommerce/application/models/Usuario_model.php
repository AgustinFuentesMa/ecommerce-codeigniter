<?php
class Usuario_model extends CI_Model {

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function existe_email($email){
        return $this->db->get_where('usuarios', ['email' => $email])->row();
    }

    public function registrar($data){
        return $this->db->insert('usuarios', $data);
    }

    public function login($email){
        return $this->db->get_where('usuarios', ['email' => $email])->row();
    }
}