<?php
class Producto_model extends CI_Model {

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function get_productos(){
        return $this->db->get('productos')->result();
    }

    public function get_producto($id){
        $this->db->where('id', $id);
        return $this->db->get('productos')->row();
    }

}